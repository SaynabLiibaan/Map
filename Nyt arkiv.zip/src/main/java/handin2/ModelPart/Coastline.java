package handin2.ModelPart;

//import java.io.Serializable;
import java.util.ArrayList;
//import java.util.List;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Coastline extends Way{
    public Coastline(ArrayList<Node> way, Long id) {
        super(way, id);
    }

   public void draw(GraphicsContext gc) {
    super.draw(gc);
    //gc.setFill(Color.DEEPSKYBLUE);
    //gc.fill();//Husk fill kaldet efter setFill.
    gc.setStroke(Color.LIGHTBLUE); //Virker pt ikke, fordi alt bliver considered Road == roads farve vises.//UPDATE WORKS
    gc.setFill(Color.GREEN);
    gc.stroke();
    }  
}