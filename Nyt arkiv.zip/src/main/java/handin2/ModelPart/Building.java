package handin2.ModelPart;

//import java.io.Serializable;
import java.util.ArrayList;
//import java.util.List;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Building extends Way{
    public Building(ArrayList<Node> way, Long id) {
        super(way, id);
    }

   public void draw(GraphicsContext gc) {
    super.draw(gc);
    gc.setFill(Color.PINK);
    gc.fill();//Husk fill kaldet efter setFill.
    gc.setStroke(Color.PINK); //Virker pt ikke, fordi alt bliver considered Road == roads farve vises.//UPDATE WORKS
    gc.stroke();

    
    }
}