package handin2.ModelPart;

//import java.io.Serializable;
import java.util.ArrayList;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Water extends Way{
    public Water(ArrayList<Node> way, Long id) {
        super(way, id);
    }

    public void draw(GraphicsContext gc) {
        super.draw(gc);
        gc.setFill(Color.LIGHTBLUE);
        gc.fill();//Husk fill kaldet efter setFill.
        gc.setStroke(Color.LIGHTBLUE); //Virker pt ikke, fordi alt bliver considered Road == roads farve vises.//UPDATE WORKS
        gc.stroke();
    }

}