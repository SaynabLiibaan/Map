package handin2.ModelPart;

//import java.io.Serializable;
import java.util.ArrayList;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Road extends Way{

    private double weight = 1.0;

    boolean isBike; 
    boolean isCar; 
    boolean isWalk; 
    int speed; 
    

    public Road(ArrayList<Node> way, Long id, int speed, boolean isBike, boolean isCar, boolean isWalk) {
        super(way, id);
        this.speed = speed; 
        this.isBike = isBike; 
        this.isCar = isCar; 

        System.out.println("Speed for road: " + id + " is: " + speed);

    }



    public Road(ArrayList<Node> way, Long id) {
        super(way, id);
    }

 
public void draw(GraphicsContext gc) {

    
    super.draw(gc);
    //gc.setFill(Color.LIGHTGRAY);
    //gc.fill();
    gc.setStroke(Color.GREY);
    gc.stroke();
    }

    public void drawPath(GraphicsContext gc){
        super.draw(gc); 
        gc.setStroke(Color.CYAN);
        gc.stroke();
    }
    public void drawFirst(GraphicsContext gc){
        super.draw(gc); 
        gc.setStroke(Color.GREEN);
        gc.stroke();
    }

    public void drawDebug(GraphicsContext gc){
        super.draw(gc); 
        gc.setStroke(Color.YELLOWGREEN);
        gc.stroke();
    }


    public double weight(){
        return weight;
    }

    public double getDistance(){

        double distance = Math.sqrt(Math.pow((last().getX() - first().getX()), 2)   + Math.pow((last().getY() - first().getY()), 2));
      
       // System.out.println( "The distance is: " + distance);
       return distance; 
      
      }

      public double speedDistance(){

        double distance = Math.sqrt(Math.pow((last().getX() - first().getX()), 2)   + Math.pow((last().getY() - first().getY()), 2));
      
        double speedDistance = distance/speed; 
       // System.out.println( "The distance is: " + distance);
       return speedDistance; 

      }

   
}