package handin2.ModelPart;

import java.util.ArrayList;
import javafx.scene.paint.Color;
import javafx.scene.canvas.GraphicsContext;

public class Area extends Way {
    String type;

    public Area(ArrayList<Node> way, String type, Long id) {
        super(way, id);
        this.type = type;
    }

    public void draw(GraphicsContext gc) {
        super.draw(gc);

        if (type == "forest"){
            gc.setFill(Color.DARKSEAGREEN);
            gc.setStroke(Color.DARKSEAGREEN); 
        }  else if (type == "residential"){
            gc.setFill(Color.LIGHTGRAY);
            gc.setStroke(Color.LIGHTGRAY);
        }   else if (type == "farmland") {
            gc.setFill(Color.PALEGOLDENROD);
            gc.setStroke(Color.PALEGOLDENROD);
        }   else if (type == "beach") {
            gc.setFill(Color.BISQUE);
            gc.setStroke(Color.BISQUE);
        }
        gc.fill();
        gc.stroke();
    }
}