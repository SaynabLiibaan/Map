package handin2.ControllerPart;

import handin2.ModelPart.Model;
import handin2.ModelPart.Node;
import handin2.ModelPart.Way;
import handin2.ModelPart.Tree.Rectangle;
import handin2.ViewPart.View;
import javafx.geometry.Point2D;
import javafx.scene.control.Label;
import javafx.scene.transform.Affine;

public class Controller {
    double lastX;
    double lastY;
    double width;
    double height;
    private int count;


    public Controller(Model model, View view) {
        //view.rectangle.setMouseTransparent(true);
        // Behavior: on mouse pressed
        
        view.canvas.setOnMousePressed(e -> {
            lastX = e.getX();
            lastY = e.getY();



            if(e.getClickCount() == 2){
                System.out.println("!!!!!  TEESSSST    !!!");
                count = count + 1;//count tælles op med 1 når der dobbelklikkes.
                if(count%2 == 1){
                  
                    System.out.println("Dijkstra");
                   // view.djFirstClick();



                } else {//lige klik
                    System.out.println("Ikke dijkstra");
                   // view.endingPath();
                }
            }
            
        });


        view.pane.setOnMouseMoved(e -> {
            String labelText = "x=" + e.getX() + "; y=" + e.getY();
            labelText += "\nlon=" + view.mousetoModel(e.getX(), e.getY()).getX()/0.56 + "; lat=" + -view.mousetoModel(e.getX(), e.getY()).getY();
            view.label.setText(labelText);
            
            //System.out.println("Coordinates " + e.getX() + " " + e.getY());

            Point2D point = view.mousetoModel(e.getX(), e.getY());
            //System.out.println("MousetoModel: " + point.getX() + " " + point.getY());
            
            Node node = view.mouseToNode(point);
            Node lonlat = new Node(-node.getY(), node.getX()/0.56, 0L);
            //System.out.println("MousetoNode: " + node.getX() + " " + node.getY());
            //System.out.println("lon/lat: " + node.getX()/0.56 + " " + -node.getY());
            
            Way finalWay = view.nearestWay(lonlat);
            //view.highlightWay(finalWay);
            
            
        });

        view.pane.setOnMouseMoved(e -> {
            String labelText = "x=" + e.getX() + "; y=" + e.getY();
            view.label.setText(labelText);
        });

        // Behavior : on mouse dragged (=> everytime you move on the map)
        view.pane.setOnMouseDragged(e -> {
            //view.rectangle.setMouseTransparent(true);
            if (e.isPrimaryButtonDown()) {
                // Get the differential coordinates
                double dx = e.getX() - lastX;
                double dy = e.getY() - lastY;

                //view.redraw();
                // Make the view move long the mouse's move
                view.pan(dx, dy);
            }

            lastX = e.getX();
            lastY = e.getY();
            
           
        });

        // Behavior: on scroll
        view.pane.setOnScroll(e -> {

            double factor = e.getDeltaY();//Number of pixels you can scroll vertically
            view.zoom(e.getX(), e.getY(), Math.pow(1.01, factor));//1.01^factor

        });


    }
    
}
